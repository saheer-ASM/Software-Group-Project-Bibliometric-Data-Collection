# REAL EMPIRICAL DATA — INTERPRET ONLY AFTER READINESS REVIEW

# Data-quality report

Counts describe the extracted snapshot, not a verified complete career dataset.

| Check | Count | Status | Detail |
|---|---:|---|---|
| duplicate_author_ids | 0 | VALID | Duplicate authoritative author key |
| duplicate_publication_ids | 0 | VALID | Duplicate authoritative paper key |
| duplicate_author_publication_pairs | 285 | WARNING | Deduplicate stable-ID pairs; duplicate slots are not additional papers |
| orphan_link_authors | 0 | VALID | Linked author absent from author |
| orphan_link_publications | 0 | VALID | Linked paper absent from publication |
| authors_without_linked_publications | 0 | VALID | Absence of a link is unknown portfolio coverage |
| publications_without_author_relationship | 0 | VALID | No stable-ID authorship in current source |
| missing_or_non_numeric_citation_counts | 0 | VALID | Required raw count absent |
| negative_citation_counts | 0 | VALID | Raw count must be nonnegative |
| invalid_publication_years | 0 | VALID | Missing or out-of-range year |
| missing_contribution_weights | 0 | VALID | Relevant only to an approved contribution-weighted strategy |
| missing_nm_rows | 0 | VALID | No authoritative NM row |
| null_nm_scores | 0 | VALID | Stored NM row with unavailable score |
| duplicate_nm_records | 0 | VALID | Duplicate NM author key |
| orphan_nm_records | 0 | VALID | NM author absent from author |
| inconsistent_citation_sources | 7794 | WARNING | Stored raw paper total differs from observed incoming edges; provenance unresolved |
