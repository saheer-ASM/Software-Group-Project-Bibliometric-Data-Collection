# REAL EMPIRICAL DATA — INTERPRET ONLY AFTER READINESS REVIEW

# Experiment status and outputs

- **rq01: DATA_REQUIRED** — correlation_matrix (4 rows), correlation_stats (3 rows), status (1 rows)
- **rq02: OK** — paired_difference_stats (3 rows)
- **rq03: METHODOLOGY_PENDING** — icc_analysis (3 rows)
- **rq04: DATA_REQUIRED** — status (1 rows)
- **rq05: DATA_REQUIRED** — status (1 rows)
- **rq06: DATA_REQUIRED** — status (1 rows)
- **rq07: METHODOLOGY_PENDING** — gaming_resistance (3316 rows), gaming_index_inflation (23212 rows), status (1 rows)
- **rq08: DATA_REQUIRED** — status (1 rows)
- **rq09: DATA_REQUIRED** — status (1 rows)
- **rq10: METHODOLOGY_PENDING** — status (1 rows)
- **rq11: DATA_REQUIRED** — status (1 rows)
- **sensitivity: DATA_REQUIRED** — sensitivity_results (4 rows), parameter_sensitivity_scores (0 rows), parameter_sensitivity_status (1 rows), status (1 rows)

## Execution and evidence state

| Experiment | Report state | Detail |
|---|---|---|
| rq01 | UNAVAILABLE_INPUT | DATA_REQUIRED |
| rq02 | IMPLEMENTED_RESULT | OK |
| rq03 | METHODOLOGY_PENDING | METHODOLOGY_PENDING |
| rq04 | UNAVAILABLE_INPUT | DATA_REQUIRED |
| rq05 | UNAVAILABLE_INPUT | DATA_REQUIRED |
| rq06 | UNAVAILABLE_INPUT | DATA_REQUIRED |
| rq07 | METHODOLOGY_PENDING | METHODOLOGY_PENDING |
| rq08 | UNAVAILABLE_INPUT | DATA_REQUIRED |
| rq09 | UNAVAILABLE_INPUT | DATA_REQUIRED |
| rq10 | METHODOLOGY_PENDING | METHODOLOGY_PENDING |
| rq11 | UNAVAILABLE_INPUT | DATA_REQUIRED |
| sensitivity | UNAVAILABLE_INPUT | DATA_REQUIRED |

No status marked pending, data-required or insufficient should be interpreted as a final finding. The numerical details and sample sizes are in the named CSVs.
