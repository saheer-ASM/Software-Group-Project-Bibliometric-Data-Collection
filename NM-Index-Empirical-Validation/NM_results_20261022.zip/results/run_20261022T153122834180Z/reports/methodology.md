# REAL EMPIRICAL DATA — INTERPRET ONLY AFTER READINESS REVIEW

# Methodology

Source versions and hashes are recorded in `run_metadata.json`. NM is loaded from `author_nm_index`; raw Total Cites, h and written g are local conventional baselines. Other baselines require source-cited approved strategies. Each result CSV declares data classification; missing experiments are status-coded. Eligibility uses separate portfolio evidence. See `experiment_eligibility.csv` for cohort counts and input gates.
