# REAL EMPIRICAL DATA — INTERPRET ONLY AFTER READINESS REVIEW

# Limitations

Methodology-pending baselines: c_score_raw, c_score_sc_adjusted, hm_index, m_index, fi_score, s_index, ar_index. Experiments requiring further methods or inputs: rq01, rq03, rq04, rq05, rq06, rq07, rq08, rq09, rq10, rq11, sensitivity. Cohort/source completeness, citation provenance, missing-data policy, historical data, award and subgroup-label provenance remain separate gates for any real study.
