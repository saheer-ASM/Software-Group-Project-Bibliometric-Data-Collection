# REAL EMPIRICAL DATA — INTERPRET ONLY AFTER READINESS REVIEW

# Metric coverage

- `raw_total_cites`: 995/995 authors
- `c_score_raw`: 0/995 authors
- `c_score_sc_adjusted`: 0/995 authors
- `h_index`: 995/995 authors
- `hm_index`: 0/995 authors
- `hf_index`: 0/995 authors
- `g_index`: 995/995 authors
- `m_index`: 0/995 authors
- `fi_score`: 0/995 authors
- `s_index`: 0/995 authors
- `ar_index`: 0/995 authors

Descriptive statistics are in `descriptive_statistics.csv`. Missing baselines are not zero-filled.
