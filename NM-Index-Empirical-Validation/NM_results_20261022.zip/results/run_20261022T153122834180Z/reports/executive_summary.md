# REAL EMPIRICAL DATA — INTERPRET ONLY AFTER READINESS REVIEW

# Run summary

Data classification: **REAL EMPIRICAL DATA — INTERPRET ONLY AFTER READINESS REVIEW**. Authors: 995; cohort eligible: 829. These outputs are software checks and descriptive results; no empirical conclusion follows from coverage alone.
